// Disalin dari file canvas pengguna (disederhanakan untuk keperluan ZIP)
import React from 'react';

export default function SehatiApp() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1 style={{ color: '#2563eb' }}>SEHATI</h1>
      <p>Sehat Bersama Teknologi – Edukasi dan Konsultasi Kesehatan Digital</p>
      <p>Website ini menyediakan seminar dan layanan konsultasi kesehatan secara daring.</p>
    </div>
  );
}
